#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\toom3_mul.c"
