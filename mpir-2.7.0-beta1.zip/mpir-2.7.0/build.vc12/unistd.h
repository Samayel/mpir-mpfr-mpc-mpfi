
#ifndef __UNISTD_H__
#define __UNISTD_H__

#include <io.h>
#include <process.h>

#include "getopt.h"

#define random rand
#define SIGHUP 1
#define access _access
#define R_OK   4

#endif
