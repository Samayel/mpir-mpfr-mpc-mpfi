#define TUNE_PROGRAM_BUILD 1
#define __gmpn_mod_1  mpn_mod_1_tune
#include "..\..\mpn\generic\mod_1.c"
